#include "libs/libretroBridge.h"

#ifdef KYTY_LIBRETRO_CORE

#include "graphics/presentation/systemOverlay.h"
#include "kyty_shared_state.h"
#include "libs/controller.h"

#include <SDL3/SDL_audio.h>
#include <windows.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#endif

namespace Kyty::LibretroBridge {

#ifndef KYTY_LIBRETRO_CORE

void SetSharedState(void*) {}
bool ShouldQuit() {
	return false;
}
void SetBaseDir(const char*) {}
const char* BaseDir() {
	return nullptr;
}
void PushFrame(const void*, uint32_t, uint32_t, uint32_t) {}
void AddAudioStream(void*) {}
void RemoveAudioStream(void*) {}
void AudioPumpLoop() {}
void PumpInput() {}

#else

namespace {

KytyLibretro::SharedState* g_shared = nullptr;
std::string g_base_dir;
std::mutex g_audio_mutex;
std::vector<SDL_AudioStream*> g_audio_streams;

void DiagLog(const char* format, ...) {
	SYSTEMTIME now {};
	GetLocalTime(&now);
	std::FILE* file = std::fopen("C:\\Users\\tommy\\AppData\\Local\\VEmu\\saves\\kytyps5_diag.log", "a");
	if (file == nullptr) {
		return;
	}
	std::fprintf(file, "[%02u:%02u:%02u.%03u pid=%lu bridge] ", now.wHour, now.wMinute,
	             now.wSecond, now.wMilliseconds, GetCurrentProcessId());
	va_list args;
	va_start(args, format);
	std::vfprintf(file, format, args);
	va_end(args);
	std::fputc('\n', file);
	std::fclose(file);
}

} // namespace

void SetSharedState(void* state) {
	g_shared = static_cast<KytyLibretro::SharedState*>(state);
}

bool ShouldQuit() {
	if (g_shared == nullptr || g_shared->magic.load(std::memory_order_acquire) !=
	                               KytyLibretro::SHARED_MAGIC ||
	    g_shared->version.load(std::memory_order_acquire) != KytyLibretro::SHARED_VERSION) {
		return false;
	}
	return g_shared->quit.load(std::memory_order_acquire) != 0;
}

void SetBaseDir(const char* path) {
	g_base_dir = path != nullptr ? path : "";
	if (!g_base_dir.empty() && g_base_dir.back() != '\\' && g_base_dir.back() != '/') {
		g_base_dir.push_back('\\');
	}
}

const char* BaseDir() {
	return g_base_dir.empty() ? nullptr : g_base_dir.c_str();
}

void PushFrame(const void* pixels, uint32_t width, uint32_t height, uint32_t format) {
	using namespace KytyLibretro;

	static std::atomic<uint32_t> diag_counter {0};
	if ((diag_counter.fetch_add(1) % 120) == 0) {
		DiagLog("PushFrame: %ux%u fmt=%u shared=%d", width, height, format,
		        g_shared != nullptr ? 1 : 0);
	}
	if (g_shared == nullptr || pixels == nullptr || width == 0 || height == 0 ||
	    width > MAX_WIDTH || height > MAX_HEIGHT) {
		if (g_shared != nullptr) {
			DiagLog("PushFrame: rejected frame %ux%u fmt=%u pixels=%d", width, height, format,
			        pixels != nullptr ? 1 : 0);
		}
		return;
	}
	const uint32_t latest = g_shared->frame_latest.load(std::memory_order_relaxed);
	const uint32_t newest = latest == 0 ? FRAME_SLOT_NONE : latest & FRAME_SLOT_MASK;
	const uint32_t held   = g_shared->frame_held.load(std::memory_order_acquire);
	uint32_t       slot   = 0;
	while (slot == newest || slot == held) {
		++slot;
	}
	auto*       dst    = SharedFrame(g_shared, slot);
	const auto* src    = static_cast<const std::uint8_t*>(pixels);
	const auto  row_bytes = width * 4;
	if (format == FORMAT_BGRA) {
		for (uint32_t y = 0; y < height; ++y) {
			std::memcpy(dst + static_cast<std::size_t>(y) * MAX_WIDTH * 4,
			            src + static_cast<std::size_t>(y) * row_bytes, row_bytes);
		}
	} else {
		for (uint32_t y = 0; y < height; ++y) {
			const auto* src_row = src + static_cast<std::size_t>(y) * row_bytes;
			auto*       dst_row = dst + static_cast<std::size_t>(y) * MAX_WIDTH * 4;
			for (uint32_t x = 0; x < width; ++x) {
				dst_row[x * 4 + 0] = src_row[x * 4 + 2];
				dst_row[x * 4 + 1] = src_row[x * 4 + 1];
				dst_row[x * 4 + 2] = src_row[x * 4 + 0];
				dst_row[x * 4 + 3] = src_row[x * 4 + 3];
			}
		}
	}
	g_shared->frame_size[slot].width  = width;
	g_shared->frame_size[slot].height = height;
	g_shared->frame_latest.store((((latest >> FRAME_SLOT_BITS) + 1) << FRAME_SLOT_BITS) | slot,
	                             std::memory_order_release);
}

void AddAudioStream(void* stream) {
	if (stream == nullptr) {
		return;
	}
	std::lock_guard lock(g_audio_mutex);
	g_audio_streams.push_back(static_cast<SDL_AudioStream*>(stream));
}

void RemoveAudioStream(void* stream) {
	std::lock_guard lock(g_audio_mutex);
	auto*           audio_stream = static_cast<SDL_AudioStream*>(stream);
	std::erase(g_audio_streams, audio_stream);
}

void AudioPumpLoop() {
	using namespace KytyLibretro;

	constexpr uint32_t chunk_frames = 1024;
	static std::int16_t chunk[chunk_frames * 2];
	static std::int32_t sum[chunk_frames * 2];

	while (!ShouldQuit()) {
		std::this_thread::sleep_for(std::chrono::milliseconds(2));
		const uint32_t written = g_shared->audio_written.load(std::memory_order_relaxed);
		const uint32_t read    = g_shared->audio_read.load(std::memory_order_acquire);
		const uint32_t queued  = written - read;
		if (queued >= AUDIO_RING_TARGET_FRAMES) {
			continue;
		}
		const uint32_t wanted = std::min(chunk_frames, AUDIO_RING_TARGET_FRAMES - queued);
		std::memset(sum, 0, sizeof(sum));
		uint32_t frames = 0;
		{
			std::lock_guard lock(g_audio_mutex);
			for (SDL_AudioStream* stream : g_audio_streams) {
				const int bytes =
				    SDL_GetAudioStreamData(stream, chunk, static_cast<int>(wanted * 4));
				const uint32_t got = bytes > 0 ? static_cast<uint32_t>(bytes) / 4 : 0;
				for (uint32_t i = 0; i < got * 2; ++i) {
					sum[i] += chunk[i];
				}
				frames = std::max(frames, got);
			}
		}
		for (uint32_t i = 0; i < frames; ++i) {
			const uint32_t at     = (written + i) & (AUDIO_RING_FRAMES - 1);
			g_shared->audio[at * 2 + 0] =
			    static_cast<std::int16_t>(std::clamp(sum[i * 2 + 0], -32768, 32767));
			g_shared->audio[at * 2 + 1] =
			    static_cast<std::int16_t>(std::clamp(sum[i * 2 + 1], -32768, 32767));
		}
		if (frames != 0) {
			g_shared->audio_written.store(written + frames, std::memory_order_release);
		}
	}
}

void PumpInput() {
	using namespace KytyLibretro;
	using namespace Libs::Controller;

	if (g_shared == nullptr || !PadInitialized()) {
		return;
	}
	static uint32_t held = 0;
	static uint32_t axis_value[AXIS_COUNT];
	static bool     axis_init = false;
	static bool     overlay_controller = false;
	if (!axis_init) {
		std::fill(std::begin(axis_value), std::end(axis_value), ~0u);
		axis_init = true;
	}
	const bool overlay_captured = Libs::Graphics::IsSystemOverlayControllerCaptureActive();
	if (overlay_captured != overlay_controller) {
		overlay_controller = overlay_captured;
		DiagLog("PumpInput: overlay_controller=%u", overlay_captured ? 1u : 0u);
		if (!overlay_controller) {
			static constexpr uint32_t buttons[] = {
			    PAD_BUTTON_L3,       PAD_BUTTON_R3,        PAD_BUTTON_OPTIONS,
			    PAD_BUTTON_UP,       PAD_BUTTON_RIGHT,     PAD_BUTTON_DOWN,
			    PAD_BUTTON_LEFT,     PAD_BUTTON_L2,        PAD_BUTTON_R2,
			    PAD_BUTTON_L1,       PAD_BUTTON_R1,        PAD_BUTTON_TRIANGLE,
			    PAD_BUTTON_CIRCLE,   PAD_BUTTON_CROSS,     PAD_BUTTON_SQUARE,
			    PAD_BUTTON_TOUCH_PAD};
			for (const uint32_t button : buttons) {
				SetButton(HOST_INPUT_CONTROLLER_ID, button, (held & button) != 0);
			}
			static constexpr Axis axes_to_resync[AXIS_COUNT] = {
			    Axis::LeftX, Axis::LeftY, Axis::RightX, Axis::RightY, Axis::TriggerLeft,
			    Axis::TriggerRight};
			for (uint32_t i = 0; i < AXIS_COUNT; ++i) {
				SetAxis(HOST_INPUT_CONTROLLER_ID, axes_to_resync[i],
				        static_cast<int>(axis_value[i]));
			}
		}
	}
	const uint32_t now     = g_shared->buttons[0].load(std::memory_order_acquire);
	const uint32_t changed = now ^ held;
	static std::atomic<uint32_t> diag_counter {0};
	if ((changed != 0) || (diag_counter.fetch_add(1) % 240) == 0) {
		DiagLog("PumpInput: now=%08x held=%08x changed=%08x overlay=%u", now, held, changed,
		        overlay_captured ? 1u : 0u);
	}
	if (changed != 0) {
		static constexpr uint32_t buttons[] = {
		    PAD_BUTTON_L3,       PAD_BUTTON_R3,        PAD_BUTTON_OPTIONS,
		    PAD_BUTTON_UP,       PAD_BUTTON_RIGHT,     PAD_BUTTON_DOWN,
		    PAD_BUTTON_LEFT,     PAD_BUTTON_L2,        PAD_BUTTON_R2,
		    PAD_BUTTON_L1,       PAD_BUTTON_R1,        PAD_BUTTON_TRIANGLE,
		    PAD_BUTTON_CIRCLE,   PAD_BUTTON_CROSS,     PAD_BUTTON_SQUARE,
		    PAD_BUTTON_TOUCH_PAD};
		for (const uint32_t button : buttons) {
			if ((changed & button) != 0) {
				const bool down = (now & button) != 0;
				if (overlay_captured) {
					Libs::Graphics::ProcessLibretroOverlayButton(button, down);
				} else {
					SetButton(HOST_INPUT_CONTROLLER_ID, button, down);
				}
			}
		}
		held = now;
	}
	static constexpr Axis axes[AXIS_COUNT] = {
	    Axis::LeftX, Axis::LeftY, Axis::RightX, Axis::RightY, Axis::TriggerLeft,
	    Axis::TriggerRight};
	for (uint32_t i = 0; i < AXIS_COUNT; ++i) {
		const uint32_t value = g_shared->axes[0][i].load(std::memory_order_acquire);
		if (value != axis_value[i]) {
			axis_value[i] = value;
			if (overlay_captured) {
				Libs::Graphics::ProcessLibretroOverlayAxis(i, static_cast<int>(value));
			} else {
				SetAxis(HOST_INPUT_CONTROLLER_ID, axes[i], static_cast<int>(value));
			}
		}
	}
}

#endif

} // namespace Kyty::LibretroBridge
