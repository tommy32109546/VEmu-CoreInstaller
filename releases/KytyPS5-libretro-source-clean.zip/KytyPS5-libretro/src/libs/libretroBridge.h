#ifndef EMULATOR_INCLUDE_EMULATOR_LIBRETRO_BRIDGE_H_
#define EMULATOR_INCLUDE_EMULATOR_LIBRETRO_BRIDGE_H_

#include <cstdint>

namespace Kyty::LibretroBridge {

void SetSharedState(void* state);
bool ShouldQuit();
void SetBaseDir(const char* path);
const char* BaseDir();
void PushFrame(const void* pixels, uint32_t width, uint32_t height, uint32_t format);
void AddAudioStream(void* stream);
void RemoveAudioStream(void* stream);
void AudioPumpLoop();
void PumpInput();

} // namespace Kyty::LibretroBridge

#endif
