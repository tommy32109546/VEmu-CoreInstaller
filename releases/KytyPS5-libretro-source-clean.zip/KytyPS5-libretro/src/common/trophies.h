#ifndef KYTY_COMMON_TROPHIES_H_
#define KYTY_COMMON_TROPHIES_H_

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <variant>
#include <vector>

namespace Common::Trophies {

inline constexpr char     PackageDirectory[] = "sce_sys/trophy2";
inline constexpr uint64_t UnixEpochTick      = 62135596800000000ULL;

enum class Comparison { None, GreaterEqual, Greater, LessEqual, Less };

struct Trophy {
	int                     id          = 0;
	int                     group_id    = -1;
	int                     platinum_id = -1;
	int                     grade       = 0;
	std::optional<uint64_t> target;
	std::optional<uint64_t> uds_stat_id;
	Comparison              comparison  = Comparison::None;
	bool                    progressive = false;
	std::string             name;
	std::string             description;
	std::string             reward;
	std::vector<std::byte>  icon_png;
	bool                    hidden     = false;
	bool                    has_reward = false;
};

struct UdsRule {
	enum class Type { Uint32, Uint64, Int64 };

	uint64_t    stat_id;
	std::string input;
	Type        type;
	bool        maximum;
	uint64_t    initial_value;
};

using UdsRules   = std::map<std::string, std::vector<UdsRule>>;
using UdsInteger = std::variant<int32_t, uint32_t, uint64_t, int64_t>;

struct Package {
	std::string                title;
	std::map<int, std::string> groups;
	std::map<int, Trophy>      trophies;
	UdsRules                   event_rules;
};

struct UnlockData {
	std::set<int>                unlocked;
	std::map<int, uint64_t>      timestamps;
	std::map<uint64_t, uint64_t> max_stats;
	std::map<int, uint64_t>      progress; // Reported by the game through _UpdateTrophyProgress.
};

struct UdsResult {
	std::vector<int> trophies;
	bool             stats_changed = false;
};

struct Progress {
	std::array<uint32_t, 5> total_grade {};
	std::array<uint32_t, 5> earned_grade {};
	uint32_t                total  = 0;
	uint32_t                earned = 0;

	[[nodiscard]] uint32_t Percentage() const;
};

[[nodiscard]] Progress GetProgress(const Package& package, const UnlockData& unlocks,
                                   std::optional<int> group = std::nullopt);

[[nodiscard]] Package LoadPackage(const std::filesystem::path& path, int console_language);
[[nodiscard]] std::filesystem::path PackagePath(uint32_t service_label);
[[nodiscard]] std::filesystem::path UdsPackagePath(uint32_t service_label);
[[nodiscard]] UdsRules              LoadUdsRules(const std::filesystem::path& path);
// Activity IDs from the activity enums of a UDS package.
[[nodiscard]] std::set<std::string> LoadActivityIds(const std::filesystem::path& path);
[[nodiscard]] UdsResult ApplyUdsEvent(const Package& package, UnlockData& unlocks,
                                      std::string_view                         event_name,
                                      const std::map<std::string, UdsInteger>& properties);
// Raises the reported progress of a locked progressive trophy; lower values are ignored.
// Returns whether the progress reached the target; `changed` reports whether `progress`
// was modified.
[[nodiscard]] bool UpdateTrophyProgress(const Package& package, int trophy_id, uint64_t value,
                                        UnlockData& unlocks, bool& changed);
// Progress of a progressive trophy from its stat or the reported progress, capped at the target.
[[nodiscard]] std::optional<uint64_t> TrophyProgress(const Trophy&     trophy,
                                                     const UnlockData& unlocks);
[[nodiscard]] std::filesystem::path   UnlocksPath(const std::filesystem::path& root,
                                                  std::string_view title_id, int user_id,
                                                  uint32_t service_label);
[[nodiscard]] UnlockData              LoadUnlockData(const std::filesystem::path& path);
[[nodiscard]] bool SaveUnlockData(const std::filesystem::path& path, const UnlockData& unlocks);

} // namespace Common::Trophies

#endif // KYTY_COMMON_TROPHIES_H_
