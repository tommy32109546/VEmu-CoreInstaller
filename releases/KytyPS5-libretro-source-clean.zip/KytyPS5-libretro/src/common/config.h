#ifndef KYTY_COMMON_CONFIG_H_
#define KYTY_COMMON_CONFIG_H_

#define KYTY_PLATFORM_WINDOWS 1
#define KYTY_PLATFORM_LINUX   5

#define KYTY_COMPILER_GCC   1
#define KYTY_COMPILER_CLANG 2

#define KYTY_BUILD_DEBUG   1
#define KYTY_BUILD_RELEASE 2

#include "cmake_config.h"

#endif /* KYTY_COMMON_CONFIG_H_ */
