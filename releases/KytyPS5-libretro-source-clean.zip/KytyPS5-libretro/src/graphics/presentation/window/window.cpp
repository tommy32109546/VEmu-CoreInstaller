﻿#include "graphics/presentation/window.h"

#include "common/assert.h"
#include "common/common.h"
#include "common/emulatorConfig.h"
#include "common/file.h"
#include "common/logging/log.h"
#include "common/profiler.h"
#include "common/stringUtils.h"
#include "common/systemInfo.h"
#include "common/threads.h"
#include "common/timer.h"
#include "graphics/host_gpu/graphicContext.h"
#include "graphics/host_gpu/renderer/render.h"
#include "graphics/host_gpu/renderer/renderContext.h"
#include "graphics/host_gpu/vulkanCommon.h"
#include "graphics/presentation/performanceOverlay.h"
#include "graphics/presentation/renderDoc.h"
#include "graphics/presentation/systemOverlay.h"
#include "graphics/presentation/window/hostInput.h"
#include "graphics/presentation/window/windowInternal.h"
#include "kytyGitVersion.h"
#include "libs/controller.h"
#include "libs/libretroBridge.h"
#include "loader/systemContent.h"

#include <SDL3/SDL.h>
#include <cstdlib>
#include <filesystem>
#include <fmt/format.h>
#include <memory>
#include <string>
#include <vector>
#include <vulkan/vk_platform.h>

#if KYTY_PLATFORM == KYTY_PLATFORM_WINDOWS
#include <dxgi1_6.h>
#include <wrl/client.h>
#endif

#include "stb_image.h"

// IWYU pragma: no_include <intrin.h>

#define KYTY_DBG_INPUT

namespace Libs::Graphics {

struct EventKeyboard {
	bool     down;
	bool     up;
	bool     pressed;
	bool     released;
	bool     repeat;
	int      scan_code;
	int      key_code;
	uint16_t mod;
	double   timestamp_seconds;
};


static Controller::Axis ControllerAxisFromSdl(int axis_id) {
	switch (axis_id) {
		case SDL_GAMEPAD_AXIS_LEFTX: return Controller::Axis::LeftX;
		case SDL_GAMEPAD_AXIS_LEFTY: return Controller::Axis::LeftY;
		case SDL_GAMEPAD_AXIS_RIGHTX: return Controller::Axis::RightX;
		case SDL_GAMEPAD_AXIS_RIGHTY: return Controller::Axis::RightY;
		case SDL_GAMEPAD_AXIS_LEFT_TRIGGER: return Controller::Axis::TriggerLeft;
		case SDL_GAMEPAD_AXIS_RIGHT_TRIGGER: return Controller::Axis::TriggerRight;
		default: return Controller::Axis::AxisMax;
	}
}

static bool ControllerAxisIsTrigger(int axis_id) {
	return axis_id == SDL_GAMEPAD_AXIS_LEFT_TRIGGER ||
	       axis_id == SDL_GAMEPAD_AXIS_RIGHT_TRIGGER;
}

static int ControllerAxisValueFromSdl(int axis_id, int axis_value) {
	return ControllerAxisIsTrigger(axis_id)
	           ? Controller::controller_get_axis(0, SDL_JOYSTICK_AXIS_MAX, axis_value)
	           : Controller::controller_get_axis(SDL_JOYSTICK_AXIS_MIN, SDL_JOYSTICK_AXIS_MAX,
	                                             axis_value);
}

struct EventMouse {
	bool   down;
	bool   up;
	bool   left;
	bool   middle;
	bool   right;
	bool   x1;
	bool   x2;
	bool   touch;
	bool   pressed;
	bool   released;
	int    num_of_clicks;
	bool   wheel;
	int    x;
	int    y;
	bool   motion;
	int    motion_x;
	int    motion_y;
	double timestamp_seconds;
};

struct EventFinger {
	bool   down;
	bool   up;
	bool   motion;
	int    touch_id;
	int    finger_id;
	float  x;
	float  y;
	float  dx;
	float  dy;
	float  pressure;
	double timestamp_seconds;
};

struct EventController {
	int    id;
	int    button;
	int    axis_id;
	int    axis_value;
	bool   down;
	bool   up;
	bool   added;
	bool   removed;
	bool   remapped;
	bool   axis;
	bool   pressed;
	bool   released;
	double timestamp_seconds;
};

namespace {

std::unique_ptr<WindowContext> g_window;
Common::Mutex                  g_luminance_mutex;
DisplayLuminance               g_luminance;

} // namespace

#if KYTY_PLATFORM == KYTY_PLATFORM_WINDOWS
// A factory caches output descriptions, so each query creates a new one.
static bool GetOutputDesc(HMONITOR monitor, DXGI_OUTPUT_DESC1* desc) {
	Microsoft::WRL::ComPtr<IDXGIFactory1> factory;
	Microsoft::WRL::ComPtr<IDXGIAdapter1> adapter;
	Microsoft::WRL::ComPtr<IDXGIOutput>   output;
	Microsoft::WRL::ComPtr<IDXGIOutput6>  output6;
	if (FAILED(CreateDXGIFactory1(IID_PPV_ARGS(&factory)))) {
		return false;
	}
	for (UINT a = 0; factory->EnumAdapters1(a, &adapter) == S_OK; a++) {
		for (UINT o = 0; adapter->EnumOutputs(o, &output) == S_OK; o++) {
			if (SUCCEEDED(output.As(&output6)) && SUCCEEDED(output6->GetDesc1(desc)) &&
			    desc->Monitor == monitor) {
				return true;
			}
		}
	}
	return false;
}

// The DXGI values include the monitor's calibration profile when one exists.
static void RefreshDisplayLuminance(SDL_Window* window) {
	auto* hwnd = static_cast<HWND>(SDL_GetPointerProperty(
	    SDL_GetWindowProperties(window), SDL_PROP_WINDOW_WIN32_HWND_POINTER, nullptr));

	DXGI_OUTPUT_DESC1 desc {};
	DisplayLuminance  luminance;
	if (GetOutputDesc(MonitorFromWindow(hwnd, MONITOR_DEFAULTTOPRIMARY), &desc) &&
	    desc.MaxLuminance > 0.0f && desc.MaxFullFrameLuminance > 0.0f) {
		luminance = {desc.MaxFullFrameLuminance, desc.MaxLuminance, desc.MinLuminance};
	}
	LOGF("Display luminance: max full frame = %g, max = %g, min = %g nits\n",
	     luminance.max_full_frame, luminance.max, luminance.min);
	Common::LockGuard lock(g_luminance_mutex);
	g_luminance = luminance;
}
#else
static void RefreshDisplayLuminance(SDL_Window* /*window*/) {}
#endif

constexpr const char* KYTY_SDL_WINDOW_CAPTION = "Game";

static void GameEventQuit(WindowLoopState& game) {
	LOGF("Event: quit\n");

	game.need_exit = true;
}

static void GameEventTerminate(WindowLoopState& game) {
	LOGF("Event: terminate\n");

	game.need_exit = true;
}

static void ToggleDesktopFullscreen() {
	if (g_window == nullptr || g_window->window == nullptr) {
		return;
	}

	const auto flags = static_cast<uint32_t>(SDL_GetWindowFlags(g_window->window));
	const bool fullscreen = (flags & SDL_WINDOW_FULLSCREEN) != 0u;
	if (!SDL_SetWindowFullscreen(g_window->window, !fullscreen)) {
		LOGF("Toggle fullscreen failed: %s\n", SDL_GetError());
	}
}

static void GameEventKeyboard(const EventKeyboard& key) {
	static SDL_Keycode fullscreen_key = SDLK_UNKNOWN;

#ifdef KYTY_DBG_INPUT
	LOGF("Key: time = %.04f, %s%s, %s%s, %s, scan = %d, key = %d, mod = %04" PRIx16 "\n",
	     key.timestamp_seconds, (key.down ? "down" : ""), (key.up ? "up" : ""),
	     (key.pressed ? "pressed" : ""), (key.released ? "released" : ""),
	     (key.repeat ? "repeat" : ""), key.scan_code, key.key_code, key.mod);
#endif

#if KYTY_PLATFORM == KYTY_PLATFORM_WINDOWS || KYTY_PLATFORM == KYTY_PLATFORM_LINUX
	if (key.down) {
		switch (key.key_code) {
			case SDLK_F1:
				if (!key.repeat) {
					RenderDocRequestCapture();
				}
				break;
			case SDLK_F11:
				if (!key.repeat) {
					ToggleDesktopFullscreen();
				}
				break;
			case SDLK_RETURN:
			case SDLK_KP_ENTER:
				if (!key.repeat && (key.mod & SDL_KMOD_ALT) != 0) {
					ToggleDesktopFullscreen();
					fullscreen_key = key.key_code;
				}
				break;
			default: break;
		}
	}

#endif

	const bool fullscreen_key_event =
	    fullscreen_key != SDLK_UNKNOWN && key.key_code == fullscreen_key;
	if (fullscreen_key_event && key.up) {
		fullscreen_key = SDLK_UNKNOWN;
	}
	if ((key.down || key.up) && !key.repeat && !fullscreen_key_event) {
		HostInputKey(key.key_code, key.down);
	}
}

static void GameEventMouse([[maybe_unused]] const EventMouse& mb) {
#ifdef KYTY_DBG_INPUT
	if (mb.wheel) {
		LOGF("Mouse wheel: time = %.04f, %s[%d, %d]\n", mb.timestamp_seconds,
		     (mb.touch ? "touch, " : ""), mb.x, mb.y);
	} else if (mb.motion) {
		LOGF("Mouse motion: time = %.04f, %s%s%s%s%s%s, [%d, %d], (%d, %d)\n", mb.timestamp_seconds,
		     (mb.left ? "left" : ""), (mb.middle ? "middle" : ""), (mb.right ? "right" : ""),
		     (mb.x1 ? "x1" : ""), (mb.x2 ? "x2" : ""), (mb.touch ? "_touch" : ""), mb.x, mb.y,
		     mb.motion_x, mb.motion_y);
	} else {
		LOGF("Mouse click: time = %.04f, %d, %s%s%s%s%s%s, %s%s, %s%s, [%d, %d]\n",
		     mb.timestamp_seconds, mb.num_of_clicks, (mb.left ? "left" : ""),
		     (mb.middle ? "middle" : ""), (mb.right ? "right" : ""), (mb.x1 ? "x1" : ""),
		     (mb.x2 ? "x2" : ""), (mb.touch ? "_touch" : ""), (mb.down ? "down" : ""),
		     (mb.up ? "up" : ""), (mb.pressed ? "pressed" : ""), (mb.released ? "released" : ""),
		     mb.x, mb.y);
	}
#endif

	if (mb.down || mb.up) {
		uint8_t mouse_button = 0;
		if (mb.left) {
			mouse_button = SDL_BUTTON_LEFT;
		} else if (mb.middle) {
			mouse_button = SDL_BUTTON_MIDDLE;
		} else if (mb.right) {
			mouse_button = SDL_BUTTON_RIGHT;
		} else if (mb.x1) {
			mouse_button = SDL_BUTTON_X1;
		} else if (mb.x2) {
			mouse_button = SDL_BUTTON_X2;
		}

		HostInputMouseButton(mouse_button, mb.down);
		if (!mb.touch && mb.left) {
			HostInputMouseTouchPad(mb.down, static_cast<float>(mb.x), static_cast<float>(mb.y));
		}
	} else if (mb.motion && !mb.touch) {
		if (mb.left) {
			HostInputMouseTouchPad(true, static_cast<float>(mb.x), static_cast<float>(mb.y));
		} else {
			HostInputMouseMotion(static_cast<float>(mb.x), static_cast<float>(mb.y));
		}
	}
}

static void GameEventFinger([[maybe_unused]] const EventFinger& f) {
#ifdef KYTY_DBG_INPUT
	if (f.motion) {
		LOGF("Finger motion: time = %.04f, %d, %d, (x,y) = [%f, %f], (dx,dy) = [%f, %f], pressure "
		     "= %f\n",
		     f.timestamp_seconds, f.touch_id, f.finger_id, f.x, f.y, f.dx, f.dy, f.pressure);
	} else {
		LOGF("Finger press: time = %.04f, %d, %d, %s%s, (x,y) = [%f, %f], (dx,dy) = [%f, %f], "
		     "pressure = %f\n",
		     f.timestamp_seconds, f.touch_id, f.finger_id, (f.down ? "down" : ""),
		     (f.up ? "up" : ""), f.x, f.y, f.dx, f.dy, f.pressure);
	}
#endif
}

static void GameEventController([[maybe_unused]] const EventController& f) {
	EXIT_NOT_IMPLEMENTED(f.remapped);

#ifdef KYTY_DBG_INPUT
	if (f.added || f.removed) {
		LOGF("Controller %s: %d, time = %.04f\n", (f.added ? "added" : "removed"), f.id,
		     f.timestamp_seconds);
	} else if (f.axis) {
		LOGF("Controller axis: %d, axis = %d, value = %d, time = %.04f\n", f.id, f.axis_id,
		     f.axis_value, f.timestamp_seconds);
	} else {
		LOGF("Controller button: "
		     "%d, %s%s, %s%s, button = %d, time = %.04f\n",
		     f.id, (f.down ? "down" : ""), (f.up ? "up" : ""), (f.pressed ? "pressed" : ""),
		     (f.released ? "released" : ""), f.button, f.timestamp_seconds);
	}
#endif

	if (f.added) {
		auto* pad = SDL_OpenGamepad(f.id);
		if (pad == nullptr) {
			LOGF("Controller: ignoring gamepad %d that could not be opened: %s\n", f.id,
			     SDL_GetError());
			return;
		}
		int id = SDL_GetJoystickID(SDL_GetGamepadJoystick(pad));
		Controller::Connect(id);
	}

	if (f.removed) {
		HostInputDisconnectGamepad(f.id);
		if (auto* pad = SDL_GetGamepadFromID(f.id); pad != nullptr) {
			Controller::Disconnect(f.id);
			SDL_CloseGamepad(pad);
		}
	}

	if (f.down || f.up) {
		HostInputPadButton(f.id, f.button, f.down);
	}

	if (f.axis) {
		if (f.axis_id == SDL_GAMEPAD_AXIS_LEFT_TRIGGER ||
		    f.axis_id == SDL_GAMEPAD_AXIS_RIGHT_TRIGGER) {
			HostInputPadTrigger(f.id, f.axis_id == SDL_GAMEPAD_AXIS_LEFT_TRIGGER,
			                    ControllerAxisValueFromSdl(f.axis_id, f.axis_value));
		} else if (const auto axis = ControllerAxisFromSdl(f.axis_id);
		           axis != Controller::Axis::AxisMax) {
			const int value = ControllerAxisValueFromSdl(f.axis_id, f.axis_value);
			if ((f.axis_id == SDL_GAMEPAD_AXIS_LEFTX || f.axis_id == SDL_GAMEPAD_AXIS_LEFTY) &&
			    HostInputGamepadAxis(f.id, f.axis_id == SDL_GAMEPAD_AXIS_LEFTX, value)) {
				return;
			}
			Controller::SetAxis(f.id, axis, value);
		}
	}
}

static void GameEventLowMemory() {
	LOGF("Event: low_memory\n");
}

void WindowContext::Resize(int new_width, int new_height) {
	if (new_width <= 0 || new_height <= 0) {
		return;
	}
	Common::LockGuard lock(mutex);
	graphic_ctx.screen_width  = static_cast<uint32_t>(new_width);
	graphic_ctx.screen_height = static_cast<uint32_t>(new_height);
}

void WindowContext::ProcessWindowEvent(const SDL_WindowEvent& event) {
	const auto& window_event = event;
	switch (window_event.type) {
		case SDL_EVENT_WINDOW_SHOWN:
			LOGF("Window %" PRIu32 " shown\n", window_event.windowID);
			break;

		case SDL_EVENT_WINDOW_HIDDEN:
			LOGF("Window %" PRIu32 " hidden\n", window_event.windowID);
			break;

		case SDL_EVENT_WINDOW_EXPOSED:
			LOGF("Window %" PRIu32 " exposed\n", window_event.windowID);
			break;

		case SDL_EVENT_WINDOW_MOVED:
			LOGF("Window %" PRIu32 " moved to %" PRId32 ",%" PRId32 "\n", window_event.windowID,
			     window_event.data1, window_event.data2);
			break;

		case SDL_EVENT_WINDOW_RESIZED:
			LOGF("Window %" PRIu32 " resized to %" PRId32 "x%" PRId32 "\n", window_event.windowID,
			     window_event.data1, window_event.data2);
			break;

		case SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED:
			LOGF("Window %" PRIu32 " size changed to %" PRId32 "x%" PRId32 "\n",
			     window_event.windowID, window_event.data1, window_event.data2);

			Resize(window_event.data1, window_event.data2);

			break;

		case SDL_EVENT_WINDOW_MINIMIZED:
			LOGF("Window %" PRIu32 " minimized\n", window_event.windowID);
			break;
		case SDL_EVENT_WINDOW_MAXIMIZED:
			LOGF("Window %" PRIu32 " maximized\n", window_event.windowID);
			break;
		case SDL_EVENT_WINDOW_RESTORED:
			LOGF("Window %" PRIu32 " restored\n", window_event.windowID);
			break;
		case SDL_EVENT_WINDOW_MOUSE_ENTER:
			LOGF("Mouse entered window %" PRIu32 "\n", window_event.windowID);
			break;
		case SDL_EVENT_WINDOW_MOUSE_LEAVE:
			LOGF("Mouse left window %" PRIu32 "\n", window_event.windowID);
			HostInputSetTouchPadMode(false);
			break;
		case SDL_EVENT_WINDOW_FOCUS_GAINED:
			LOGF("Window %" PRIu32 " gained keyboard focus\n", window_event.windowID);
			break;
		case SDL_EVENT_WINDOW_FOCUS_LOST:
			LOGF("Window %" PRIu32 " lost keyboard focus\n", window_event.windowID);
			break;
		case SDL_EVENT_WINDOW_CLOSE_REQUESTED:
			LOGF("Window %" PRIu32 " closed\n", window_event.windowID);
			break;
		case SDL_EVENT_WINDOW_DISPLAY_CHANGED:
		case SDL_EVENT_WINDOW_HDR_STATE_CHANGED: RefreshDisplayLuminance(window); break;
		default:
			LOGF("Window %" PRIu32 " got unknown event %" PRIu32 "\n", window_event.windowID,
			     static_cast<uint32_t>(window_event.type));
			break;
	}
}

void WindowContext::ProcessDisplayEvent(const SDL_DisplayEvent& display) {
	switch (display.type) {
		case SDL_EVENT_DISPLAY_ORIENTATION: {
			LOGF("Display %" PRIu32 " changed orientation to %d - ", display.displayID,
			     static_cast<int>(display.data1));

			switch (display.data1) {
				case SDL_ORIENTATION_UNKNOWN: LOGF("UNKNOWN\n"); break;
				case SDL_ORIENTATION_LANDSCAPE: LOGF("LANDSCAPE\n"); break;
				case SDL_ORIENTATION_LANDSCAPE_FLIPPED: LOGF("LANDSCAPE_FLIPPED\n"); break;
				case SDL_ORIENTATION_PORTRAIT: LOGF("PORTRAIT\n"); break;
				case SDL_ORIENTATION_PORTRAIT_FLIPPED: LOGF("PORTRAIT_FLIPPED\n"); break;
				default: LOGF("???\n");
			}

			break;
		}
		default:
			LOGF("Display %" PRIu32 " got unknown event 0x%" PRIx32 "\n", display.displayID,
			     static_cast<uint32_t>(display.type));
			break;
	}
}

void WindowContext::ProcessEvent(double time_s) {
	auto& game  = loop;
	auto* event = &game.event;
	if (event->type == SDL_EVENT_KEY_DOWN || event->type == SDL_EVENT_KEY_UP) {
		const bool pressed = event->type == SDL_EVENT_KEY_DOWN && event->key.repeat == 0;
		switch (event->key.key) {
			case SDLK_F7:
				if (pressed) {
					HostInputToggleMouseToJoystick();
				}
				return;
			case SDLK_F8:
				if (pressed) {
					Controller::CycleKeyboardPlayer();
				}
				return;
#if defined(__APPLE__)
			case SDLK_P:
				if ((event->key.mod & SDL_KMOD_GUI) == 0) {
					break;
				}
				[[fallthrough]];
#endif
			case SDLK_F2:
				if (pressed) {
					if ((event->key.mod & SDL_KMOD_SHIFT) != 0) {
						TogglePerformanceOverlayDetails();
					} else {
						TogglePerformanceOverlay();
					}
				}
				return;
			default: break;
		}
	}
	if (ProcessSystemOverlayInput(*event)) {
		return;
	}
	if (event->type >= SDL_EVENT_WINDOW_FIRST && event->type <= SDL_EVENT_WINDOW_LAST) {
		ProcessWindowEvent(event->window);
		return;
	}
	if (event->type >= SDL_EVENT_DISPLAY_FIRST && event->type <= SDL_EVENT_DISPLAY_LAST) {
		ProcessDisplayEvent(event->display);
		return;
	}

	switch (event->type) {
		case SDL_EVENT_QUIT: GameEventQuit(game); break;

		case SDL_EVENT_TERMINATING: GameEventTerminate(game); break;

		case SDL_EVENT_LOW_MEMORY: GameEventLowMemory(); break;

		case SDL_EVENT_KEY_DOWN:
		case SDL_EVENT_KEY_UP: {
			EventKeyboard key {};

			key.down              = (event->type == SDL_EVENT_KEY_DOWN);
			key.up                = (event->type == SDL_EVENT_KEY_UP);
			key.pressed           = event->key.down;
			key.released          = !event->key.down;
			key.repeat            = (event->key.repeat != 0u);
			key.scan_code         = event->key.scancode;
			key.key_code          = event->key.key;
			key.mod               = event->key.mod;
			key.timestamp_seconds = time_s;

			GameEventKeyboard(key);

			break;
		}

		case SDL_EVENT_MOUSE_BUTTON_DOWN:
		case SDL_EVENT_MOUSE_BUTTON_UP: {
			EventMouse mb {};

			mb.down              = (event->button.type == SDL_EVENT_MOUSE_BUTTON_DOWN);
			mb.up                = (event->button.type == SDL_EVENT_MOUSE_BUTTON_UP);
			mb.left              = (event->button.button == SDL_BUTTON_LEFT);
			mb.middle            = (event->button.button == SDL_BUTTON_MIDDLE);
			mb.right             = (event->button.button == SDL_BUTTON_RIGHT);
			mb.x1                = (event->button.button == SDL_BUTTON_X1);
			mb.x2                = (event->button.button == SDL_BUTTON_X2);
			mb.touch             = (event->button.which == SDL_TOUCH_MOUSEID);
			mb.pressed           = event->button.down;
			mb.released          = !event->button.down;
			mb.num_of_clicks     = event->button.clicks;
			mb.wheel             = false;
			mb.x                 = event->button.x;
			mb.y                 = event->button.y;
			mb.motion            = false;
			mb.motion_x          = 0;
			mb.motion_y          = 0;
			mb.timestamp_seconds = time_s;

			GameEventMouse(mb);

			break;
		}

		case SDL_EVENT_MOUSE_WHEEL: {
			EventMouse mb {};

			mb.down              = false;
			mb.up                = false;
			mb.left              = false;
			mb.middle            = false;
			mb.right             = false;
			mb.x1                = false;
			mb.x2                = false;
			mb.touch             = (event->wheel.which == SDL_TOUCH_MOUSEID);
			mb.pressed           = false;
			mb.released          = false;
			mb.num_of_clicks     = 0;
			mb.wheel             = true;
			mb.x                 = event->wheel.x;
			mb.y                 = event->wheel.y;
			mb.motion            = false;
			mb.motion_x          = 0;
			mb.motion_y          = 0;
			mb.timestamp_seconds = time_s;

			GameEventMouse(mb);

			break;
		}

		case SDL_EVENT_MOUSE_MOTION: {
			EventMouse mb {};

			mb.down              = false;
			mb.up                = false;
			mb.left              = ((event->motion.state & SDL_BUTTON_LMASK) != 0u);
			mb.middle            = ((event->motion.state & SDL_BUTTON_MMASK) != 0u);
			mb.right             = ((event->motion.state & SDL_BUTTON_RMASK) != 0u);
			mb.x1                = ((event->motion.state & SDL_BUTTON_X1MASK) != 0u);
			mb.x2                = ((event->motion.state & SDL_BUTTON_X2MASK) != 0u);
			mb.touch             = (event->motion.which == SDL_TOUCH_MOUSEID);
			mb.pressed           = false;
			mb.released          = false;
			mb.num_of_clicks     = 0;
			mb.wheel             = false;
			mb.x                 = event->motion.x;
			mb.y                 = event->motion.y;
			mb.motion            = true;
			mb.motion_x          = event->motion.xrel;
			mb.motion_y          = event->motion.yrel;
			mb.timestamp_seconds = time_s;

			GameEventMouse(mb);

			break;
		}

		case SDL_EVENT_FINGER_MOTION:
		case SDL_EVENT_FINGER_DOWN:
		case SDL_EVENT_FINGER_UP: {
			EventFinger f {};

			f.down              = (event->tfinger.type == SDL_EVENT_FINGER_DOWN);
			f.up                = (event->tfinger.type == SDL_EVENT_FINGER_UP);
			f.motion            = (event->tfinger.type == SDL_EVENT_FINGER_MOTION);
			f.finger_id         = static_cast<int>(event->tfinger.fingerID);
			f.touch_id          = static_cast<int>(event->tfinger.touchID);
			f.x                 = event->tfinger.x;
			f.y                 = event->tfinger.y;
			f.dx                = event->tfinger.dx;
			f.dy                = event->tfinger.dy;
			f.pressure          = event->tfinger.pressure;
			f.timestamp_seconds = time_s;

			GameEventFinger(f);

			break;
		}

		case SDL_EVENT_GAMEPAD_AXIS_MOTION: {
			EventController c {};

			c.id                = event->gaxis.which;
			c.button            = SDL_GAMEPAD_BUTTON_INVALID;
			c.axis_id           = event->gaxis.axis;
			c.axis_value        = event->gaxis.value;
			c.down              = false;
			c.up                = false;
			c.added             = false;
			c.removed           = false;
			c.remapped          = false;
			c.axis              = true;
			c.pressed           = false;
			c.released          = false;
			c.timestamp_seconds = time_s;

			GameEventController(c);

			break;
		}

		case SDL_EVENT_GAMEPAD_BUTTON_DOWN:
		case SDL_EVENT_GAMEPAD_BUTTON_UP: {
			EventController c {};

			c.id                = event->gbutton.which;
			c.button            = event->gbutton.button;
			c.axis_id           = SDL_GAMEPAD_AXIS_INVALID;
			c.axis_value        = 0;
			c.down              = event->gbutton.down;
			c.up                = !event->gbutton.down;
			c.added             = false;
			c.removed           = false;
			c.remapped          = false;
			c.axis              = false;
			c.pressed           = event->gbutton.down;
			c.released          = !event->gbutton.down;
			c.timestamp_seconds = time_s;

			GameEventController(c);

			break;
		}

		case SDL_EVENT_GAMEPAD_TOUCHPAD_DOWN:
		case SDL_EVENT_GAMEPAD_TOUCHPAD_MOTION:
		case SDL_EVENT_GAMEPAD_TOUCHPAD_UP:
			if (event->gtouchpad.touchpad == 0) {
				Controller::SetTouchPad(event->gtouchpad.which, event->gtouchpad.finger,
				                        event->gtouchpad.type != SDL_EVENT_GAMEPAD_TOUCHPAD_UP,
				                        event->gtouchpad.x, event->gtouchpad.y);
			}
			break;

		case SDL_EVENT_GAMEPAD_SENSOR_UPDATE: {
			const auto& sensor = event->gsensor;
			if (sensor.sensor == SDL_SENSOR_ACCEL || sensor.sensor == SDL_SENSOR_GYRO) {
				Controller::SetSensor(sensor.which,
				                      sensor.sensor == SDL_SENSOR_ACCEL ? Controller::Sensor::Accel
				                                                        : Controller::Sensor::Gyro,
				                      sensor.data,
				                      sensor.sensor_timestamp != 0
				                          ? sensor.sensor_timestamp / 1000
				                          : sensor.timestamp / 1000);
			}
			break;
		}

		case SDL_EVENT_GAMEPAD_ADDED:
		case SDL_EVENT_GAMEPAD_REMOVED:
		case SDL_EVENT_GAMEPAD_REMAPPED: {
			EventController c {};

			c.id                = event->gdevice.which;
			c.button            = SDL_GAMEPAD_BUTTON_INVALID;
			c.axis_id           = SDL_GAMEPAD_AXIS_INVALID;
			c.axis_value        = 0;
			c.down              = false;
			c.up                = false;
			c.added             = (event->gdevice.type == SDL_EVENT_GAMEPAD_ADDED);
			c.removed           = (event->gdevice.type == SDL_EVENT_GAMEPAD_REMOVED);
			c.remapped          = (event->gdevice.type == SDL_EVENT_GAMEPAD_REMAPPED);
			c.axis              = false;
			c.pressed           = false;
			c.released          = false;
			c.timestamp_seconds = time_s;

			GameEventController(c);

			break;
		}
	}
}

void WindowContext::Run() {
	Common::Timer timer;

	loop.event     = {};
	loop.need_exit = false;

	constexpr uint64_t title_interval_ms = 1000;
	auto               title_time        = SDL_GetTicks();
	auto               title_frames      = loop.presented_frames.load(std::memory_order_relaxed);

	while (!loop.need_exit) {
		// Refresh the title on the main thread without making presentation wait for it.
		const auto now     = SDL_GetTicks();
		const auto elapsed = now - title_time;
		if (elapsed >= title_interval_ms) {
			const auto frames = loop.presented_frames.load(std::memory_order_relaxed);
			if (frames != 0) {
				UpdateTitle(frames, static_cast<double>(frames - title_frames) * 1000.0 /
				                        static_cast<double>(elapsed));
			}
			title_time   = now;
			title_frames = frames;
		}
		const auto wait_ms = static_cast<int>(title_interval_ms - (now - title_time));
		if (!HostInputWaitEvent(&loop.event, wait_ms)) {
			continue;
		}
		ProcessEvent(timer.GetTimeS());
	}
}

void WindowContext::RunLibretro() {
	Common::Timer timer;
	loop.event     = {};
	loop.need_exit = false;
	while (!Kyty::LibretroBridge::ShouldQuit()) {
		if (HostInputWaitEvent(&loop.event, 2)) {
			ProcessEvent(timer.GetTimeS());
		}
		Kyty::LibretroBridge::PumpInput();
	}
	loop.need_exit = true;
}

static void WindowCreate(WindowContext& context) {
	EXIT_IF(context.window != nullptr);
	EXIT_IF(context.graphic_ctx.screen_width == 0);
	EXIT_IF(context.graphic_ctx.screen_height == 0);

	int width  = static_cast<int>(context.graphic_ctx.screen_width);
	int height = static_cast<int>(context.graphic_ctx.screen_height);

#if KYTY_PLATFORM == KYTY_PLATFORM_LINUX
	// RenderDoc can hide Wayland Vulkan surface support; prefer X11 for captures.
	if (Config::RenderDocEnabled()) {
		SDL_SetHint(SDL_HINT_VIDEO_DRIVER, "x11,wayland");
	}
#endif
	if (!SDL_InitSubSystem(SDL_INIT_VIDEO | SDL_INIT_GAMEPAD)) {
		EXIT("%s\n", SDL_GetError());
	}

	LOGF("WindowCreate(): width = %d, height = %d\n", width, height);

	uint32_t window_flags = WindowContext::InitialWindowFlags(Config::FullscreenEnabled());
#if defined(__APPLE__)
	// SDL loads Vulkan while creating a Vulkan window, so select the bundled
	// MoltenVK loader before calling SDL_CreateWindow. Keep an explicit user
	// override, and fall back to SDL's normal loader search when no bundle is present.
	if (std::getenv("SDL_VULKAN_LIBRARY") == nullptr) {
		if (const char* base_path = SDL_GetBasePath(); base_path != nullptr) {
			const std::string base_path_str = base_path;
			std::string moltenvk_path = base_path_str + "libMoltenVK.dylib";
			if (!Common::File::IsFileExisting(moltenvk_path)) {
				moltenvk_path = base_path_str + "../Frameworks/libMoltenVK.dylib";
			}
			if (Common::File::IsFileExisting(moltenvk_path) &&
			    SDL_setenv_unsafe("SDL_VULKAN_LIBRARY", moltenvk_path.c_str(), 0) == 0) {
				LOGF("Vulkan loader: %s\n", moltenvk_path.c_str());
			}
		}
	}

	// macOS 26 window chrome (CoreUI asset decode, SwiftUI titlebar) has been observed
	// throwing NSExceptions under Rosetta during the first CATransaction commit. A
	// borderless window skips that machinery entirely.
	if (std::getenv("KYTY_BORDERLESS") != nullptr) {
		window_flags |= static_cast<uint32_t>(SDL_WINDOW_BORDERLESS);
	}
#endif
	context.window = SDL_CreateWindow(KYTY_SDL_WINDOW_CAPTION, width, height, window_flags);

	if (context.window == nullptr) {
		EXIT("%s\n", SDL_GetError());
	}

	RefreshDisplayLuminance(context.window);
	SDL_SetWindowPosition(context.window, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED);
	HostInputInit(context.window);
	InitializeSystemOverlayInput(context.window);
	context.UpdateIcon();
}

uint32_t WindowContext::InitialWindowFlags(bool fullscreen) noexcept {
	auto flags = static_cast<uint32_t>(SDL_WINDOW_VULKAN | SDL_WINDOW_RESIZABLE);
	if (Config::LibretroBridgeEnabled()) {
		flags |= static_cast<uint32_t>(SDL_WINDOW_HIDDEN);
	}
	if (fullscreen) {
		flags |= static_cast<uint32_t>(SDL_WINDOW_FULLSCREEN);
	}
	return flags;
}

Presenter& WindowInit(uint32_t width, uint32_t height) {
	EXIT_NOT_IMPLEMENTED(!Common::Thread::IsMainThread());
	EXIT_IF(g_window != nullptr);

	auto window = std::make_unique<WindowContext>();

	window->graphic_ctx.screen_width  = width;
	window->graphic_ctx.screen_height = height;

	WindowCreate(*window);
	window->CreateVulkan();
	auto& presenter = *window->presenter;
	g_window        = std::move(window);
	return presenter;
}

void WindowRun() {
	KYTY_PROFILER_THREAD("Thread_Window");
	EXIT_IF(g_window == nullptr);

	if (Config::LibretroBridgeEnabled()) {
		g_window->RunLibretro();
	} else {
		g_window->Run();
	}
	Common::LockGuard lock(g_window->render_context->GetMutex());
	g_window->render_context->GetPipelineCache().Save();
}

void WindowShutdown() {
	if (g_window != nullptr) {
		HostInputShutdown();
		Controller::EmergencyShutdown();
		g_window.reset();
	}
}

DisplayLuminance WindowGetDisplayLuminance() {
	Common::LockGuard lock(g_luminance_mutex);
	return g_luminance;
}

static int WindowIconRead(void* user, char* data, int size) {
	auto*    src        = static_cast<Common::File*>(user);
	uint32_t bytes_read = 0;
	src->Read(data, static_cast<uint32_t>(size), &bytes_read);
	return static_cast<int>(bytes_read);
}

static void WindowIconSkip(void* user, int n) {
	auto*          src      = static_cast<Common::File*>(user);
	const uint64_t position = src->Tell();

	if (n >= 0) {
		src->Seek(position + static_cast<uint64_t>(n));
	} else {
		const uint64_t distance = static_cast<uint64_t>(-static_cast<int64_t>(n));
		EXIT_IF(distance > position);
		src->Seek(position - distance);
	}
}

static int WindowIconEof(void* user) {
	auto* src = static_cast<Common::File*>(user);
	return src->IsEOF() ? 1 : 0;
}

struct WindowIcon {
	SDL_Surface* surface = nullptr;
	void*        pixels  = nullptr;

	~WindowIcon() {
		SDL_DestroySurface(surface);
		stbi_image_free(pixels);
	}
};

static void WindowLoadPngIcon(const std::filesystem::path& path, WindowIcon* icon) {
	Common::File f;
	if (!f.Open(path, Common::File::Mode::Read)) {
		EXIT("Can't open icon file %s\n", Common::PathToString(path).c_str());
	}

	int width  = 0;
	int height = 0;

	stbi_io_callbacks cb {};
	cb.read = WindowIconRead;
	cb.skip = WindowIconSkip;
	cb.eof  = WindowIconEof;

	icon->pixels = stbi_load_from_callbacks(&cb, &f, &width, &height, nullptr, 4);
	f.Close();

	EXIT_IF(icon->pixels == nullptr);

	icon->surface = SDL_CreateSurfaceFrom(width, height, SDL_PIXELFORMAT_RGBA32, icon->pixels,
	                                      width * 4);
	EXIT_NOT_IMPLEMENTED(icon->surface == nullptr);
}

void WindowContext::UpdateIcon() {
	static WindowIcon icon;
	static bool       icon_loaded = false;

	if (!icon_loaded) {
		std::filesystem::path icon_path;
		if (Loader::SystemContentGetIconPath(&icon_path)) {
			WindowLoadPngIcon(icon_path, &icon);
		}
		icon_loaded = true;
	}

	if (icon.surface != nullptr) {
		SDL_SetWindowIcon(window, icon.surface);
	}
}

void WindowContext::UpdateTitle(uint64_t frame_num, double current_fps) {
	static char title[128];
	static char title_id[12];
	static char app_ver[12];
	static bool has_title = Loader::SystemContentParamSfoGetString("TITLE", title, sizeof(title));
	static bool has_title_id =
	    Loader::SystemContentParamSfoGetString("TITLE_ID", title_id, sizeof(title_id));
	static bool has_app_ver =
	    Loader::SystemContentParamSfoGetString("APP_VER", app_ver, sizeof(app_ver));
	static const std::string processor_name = Common::GetSystemInfo().ProcessorName;

	static constexpr auto build_type = KYTY_BUILD == KYTY_BUILD_DEBUG ? "Debug" : "Release";

	const auto* device_name = graphic_ctx.GetPhysicalDeviceProperties().deviceName.data();
	auto text = fmt::format(
	    "[{} | {}] {}{}{}{}{}{}[{}] [{}], frame: {}, fps: {:.0f}", KYTY_BUILD_LABEL, build_type,
	    (has_title ? title : ""), (has_title ? ", " : ""), (has_title_id ? title_id : ""),
	    (has_title_id ? ", " : ""), (has_app_ver ? app_ver : ""), (has_app_ver ? " " : ""),
	    device_name, processor_name, frame_num, current_fps);

	SDL_SetWindowTitle(window, text.c_str());
}

} // namespace Libs::Graphics
