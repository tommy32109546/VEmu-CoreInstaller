#ifndef KYTYPS5_LIBRETRO_SHARED_STATE_H
#define KYTYPS5_LIBRETRO_SHARED_STATE_H

#include <atomic>
#include <cstdint>

namespace KytyLibretro {

constexpr std::uint32_t SHARED_MAGIC = 0x3559544b;
constexpr std::uint32_t SHARED_VERSION = 1;
constexpr std::uint32_t MAX_WIDTH = 1920;
constexpr std::uint32_t MAX_HEIGHT = 1080;
constexpr std::uint32_t FRAME_SLOTS = 3;
constexpr std::uint32_t FRAME_SLOT_NONE = 7;
constexpr std::uint32_t FRAME_SLOT_BITS = 3;
constexpr std::uint32_t FRAME_SLOT_MASK = 7;
constexpr std::uint32_t FRAME_BYTES = MAX_WIDTH * MAX_HEIGHT * 4;
constexpr std::uint32_t AUDIO_RING_FRAMES = 32768;
constexpr std::uint32_t AUDIO_RING_TARGET_FRAMES = 8192;
constexpr std::uint32_t MAX_PADS = 4;
constexpr std::uint32_t AXIS_COUNT = 6;

constexpr std::uint32_t FORMAT_RGBA = 0;
constexpr std::uint32_t FORMAT_BGRA = 1;

constexpr std::uint32_t AXIS_LEFT_X = 0;
constexpr std::uint32_t AXIS_LEFT_Y = 1;
constexpr std::uint32_t AXIS_RIGHT_X = 2;
constexpr std::uint32_t AXIS_RIGHT_Y = 3;
constexpr std::uint32_t AXIS_TRIGGER_LEFT = 4;
constexpr std::uint32_t AXIS_TRIGGER_RIGHT = 5;

struct FrameSize {
	std::uint32_t width = 0;
	std::uint32_t height = 0;
};

struct SharedState {
	std::atomic<std::uint32_t> magic;
	std::atomic<std::uint32_t> version;
	std::atomic<std::uint32_t> quit;
	std::atomic<std::uint32_t> ready;
	std::atomic<std::uint32_t> pads;
	std::atomic<std::uint32_t> screen_width;
	std::atomic<std::uint32_t> screen_height;
	char game_path[4096];
	char user_dir[4096];

	std::atomic<std::uint32_t> frame_latest;
	std::atomic<std::uint32_t> frame_held;
	FrameSize frame_size[FRAME_SLOTS];
	std::uint8_t frames[FRAME_SLOTS][FRAME_BYTES];

	std::atomic<std::uint32_t> audio_written;
	std::atomic<std::uint32_t> audio_read;
	std::int16_t audio[AUDIO_RING_FRAMES * 2];

	std::atomic<std::uint32_t> buttons[MAX_PADS];
	std::atomic<std::uint32_t> axes[MAX_PADS][AXIS_COUNT];
	std::atomic<std::uint32_t> rumble[MAX_PADS];
};

inline std::uint8_t* SharedFrame(SharedState* state, std::uint32_t slot) {
	return state->frames[slot];
}

inline const std::uint8_t* SharedFrame(const SharedState* state, std::uint32_t slot) {
	return state->frames[slot];
}

} // namespace KytyLibretro

#endif
