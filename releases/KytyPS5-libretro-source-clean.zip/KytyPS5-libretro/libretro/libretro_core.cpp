#include "libretro.h"
#include "kyty_shared_state.h"
#include "libs/libretroBridge.h"

#include "common/archive.h"
#include "common/common.h"
#include "common/emulatorConfig.h"
#include "common/file.h"
#include "common/logging/log.h"
#include "common/stringUtils.h"
#include "common/threads.h"
#include "emulator.h"

#include <windows.h>

#include <SDL3/SDL.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <exception>
#include <filesystem>
#include <string>
#include <thread>
#include <vector>

namespace {

retro_environment_t             environ_cb       = nullptr;
retro_video_refresh_t           video_refresh_cb = nullptr;
retro_audio_sample_t            audio_sample_cb  = nullptr;
retro_audio_sample_batch_t      audio_batch_cb   = nullptr;
retro_input_poll_t              input_poll_cb    = nullptr;
retro_input_state_t             input_state_cb   = nullptr;
KytyLibretro::SharedState*      shared           = nullptr;
HANDLE                          shared_mapping   = nullptr;
HANDLE                          host_process     = nullptr;
HANDLE                          monitor_thread   = nullptr;
std::atomic<DWORD>              emulator_thread_id {0};
std::atomic<DWORD>              audio_thread_id    {0};
std::atomic<uint32_t>           mapping_counter  {0};
uint64_t                        shown_latest     = 0;
std::vector<uint8_t>            frame_copy;
std::vector<int16_t>            audio_copy;

void DiagLog(const char* format, ...) {
	SYSTEMTIME now {};
	GetLocalTime(&now);
	std::FILE* file = std::fopen("C:\\Users\\tommy\\AppData\\Local\\VEmu\\saves\\kytyps5_diag.log", "a");
	if (file == nullptr) {
		return;
	}
	std::fprintf(file, "[%02u:%02u:%02u.%03u pid=%lu] ", now.wHour, now.wMinute, now.wSecond,
	             now.wMilliseconds, GetCurrentProcessId());
	va_list args;
	va_start(args, format);
	std::vfprintf(file, format, args);
	va_end(args);
	std::fputc('\n', file);
	std::fclose(file);
}

LONG WINAPI DiagExceptionFilter(PEXCEPTION_POINTERS exception) {
	if (exception == nullptr || exception->ExceptionRecord == nullptr) {
		return EXCEPTION_CONTINUE_SEARCH;
	}
	const DWORD code = exception->ExceptionRecord->ExceptionCode;
	if (code != EXCEPTION_STACK_OVERFLOW && code != EXCEPTION_ACCESS_VIOLATION &&
	    code != EXCEPTION_ILLEGAL_INSTRUCTION) {
		return EXCEPTION_CONTINUE_SEARCH;
	}
	static std::atomic<uint32_t> veh_log_seq {0};
	const uint32_t               seq = veh_log_seq.fetch_add(1, std::memory_order_relaxed) + 1;
	if (seq > 64 && (seq & 4095) != 0) {
		return EXCEPTION_CONTINUE_SEARCH;
	}
	const auto* context = exception->ContextRecord;
	DiagLog("VEH: seq=%u code=0x%08lx address=%p rip=%p rsp=%p tid=%lu emu_tid=%lu audio_tid=%lu",
	        seq, code, exception->ExceptionRecord->ExceptionAddress,
	        reinterpret_cast<void*>(context != nullptr ? context->Rip : 0),
	        reinterpret_cast<void*>(context != nullptr ? context->Rsp : 0), GetCurrentThreadId(),
	        emulator_thread_id.load(), audio_thread_id.load());
	return EXCEPTION_CONTINUE_SEARCH;
}

DWORD WINAPI HostMonitorThread(LPVOID) {
	for (;;) {
		if (host_process == nullptr) {
			return 0;
		}
		const DWORD result = WaitForSingleObject(host_process, 1000);
		if (result == WAIT_OBJECT_0) {
			DWORD code = 0;
			GetExitCodeProcess(host_process, &code);
			DiagLog("HostMonitor: host exited code=%lu", code);
			return 0;
		}
	}
}

DWORD WINAPI LogFlushThread(LPVOID) {
	using namespace KytyLibretro;

	for (;;) {
		std::this_thread::sleep_for(std::chrono::milliseconds(250));
		Log::Flush();
		if (shared != nullptr) {
			DiagLog("LogFlush: frame_latest=%llu quit=%u",
			        static_cast<unsigned long long>(
			            shared->frame_latest.load(std::memory_order_acquire)),
			        shared->quit.load(std::memory_order_acquire));
		}
	}
}

void CopyText(char* destination, size_t size, const char* source) {
	if (size == 0) {
		return;
	}
	if (source == nullptr) {
		destination[0] = '\0';
		return;
	}
	std::strncpy(destination, source, size - 1);
	destination[size - 1] = '\0';
}

std::wstring Utf8ToWide(const std::string& value) {
	if (value.empty()) {
		return {};
	}
	const int size = MultiByteToWideChar(CP_UTF8, 0, value.c_str(), -1, nullptr, 0);
	if (size <= 0) {
		return {};
	}
	std::wstring result(static_cast<size_t>(size), L'\0');
	MultiByteToWideChar(CP_UTF8, 0, value.c_str(), -1, result.data(), size);
	result.resize(static_cast<size_t>(size - 1));
	return result;
}

std::string WideToUtf8(const std::wstring& value) {
	if (value.empty()) {
		return {};
	}
	const int size = WideCharToMultiByte(CP_UTF8, 0, value.c_str(), -1, nullptr, 0, nullptr,
	                                     nullptr);
	if (size <= 0) {
		return {};
	}
	std::string result(static_cast<size_t>(size), '\0');
	WideCharToMultiByte(CP_UTF8, 0, value.c_str(), -1, result.data(), size, nullptr, nullptr);
	result.resize(static_cast<size_t>(size - 1));
	return result;
}

std::string CoreDirectory() {
	HMODULE module = nullptr;
	GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
	                       GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
	                   reinterpret_cast<LPCWSTR>(&retro_init), &module);
	std::wstring path(32768, L'\0');
	const DWORD length = GetModuleFileNameW(module, path.data(), static_cast<DWORD>(path.size()));
	if (length == 0 || length >= path.size()) {
		return {};
	}
	path.resize(length);
	return WideToUtf8(std::filesystem::path(path).parent_path().wstring());
}

KytyLibretro::SharedState* OpenShared(const char* name) {
	const HANDLE mapping = OpenFileMappingA(FILE_MAP_ALL_ACCESS, FALSE, name);
	if (mapping == nullptr) {
		return nullptr;
	}
	auto* state = static_cast<KytyLibretro::SharedState*>(
	    MapViewOfFile(mapping, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(KytyLibretro::SharedState)));
	if (state == nullptr || state->magic.load() != KytyLibretro::SHARED_MAGIC ||
	    state->version.load() != KytyLibretro::SHARED_VERSION) {
		if (state != nullptr) {
			UnmapViewOfFile(state);
		}
		CloseHandle(mapping);
		return nullptr;
	}
	return state;
}

void SendInput() {
	using namespace KytyLibretro;

	if (shared == nullptr || input_state_cb == nullptr) {
		return;
	}
	static constexpr struct {
		unsigned id;
		uint32_t bit;
	} buttons[] = {
	    {RETRO_DEVICE_ID_JOYPAD_B, 0x00004000},
	    {RETRO_DEVICE_ID_JOYPAD_A, 0x00002000},
	    {RETRO_DEVICE_ID_JOYPAD_Y, 0x00008000},
	    {RETRO_DEVICE_ID_JOYPAD_X, 0x00001000},
	    {RETRO_DEVICE_ID_JOYPAD_UP, 0x00000010},
	    {RETRO_DEVICE_ID_JOYPAD_DOWN, 0x00000040},
	    {RETRO_DEVICE_ID_JOYPAD_LEFT, 0x00000080},
	    {RETRO_DEVICE_ID_JOYPAD_RIGHT, 0x00000020},
	    {RETRO_DEVICE_ID_JOYPAD_L, 0x00000400},
	    {RETRO_DEVICE_ID_JOYPAD_R, 0x00000800},
	    {RETRO_DEVICE_ID_JOYPAD_L2, 0x00000100},
	    {RETRO_DEVICE_ID_JOYPAD_R2, 0x00000200},
	    {RETRO_DEVICE_ID_JOYPAD_L3, 0x00000002},
	    {RETRO_DEVICE_ID_JOYPAD_R3, 0x00000004},
	    {RETRO_DEVICE_ID_JOYPAD_START, 0x00000008},
	    {RETRO_DEVICE_ID_JOYPAD_SELECT, 0x00100000}};

	uint32_t held = 0;
	for (const auto& button : buttons) {
		if (input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, button.id) != 0) {
			held |= button.bit;
		}
	}
	static uint32_t logged_held = ~0u;
	if (held != logged_held) {
		DiagLog("SendInput: held=%08x", held);
		logged_held = held;
	}
	shared->buttons[0].store(held, std::memory_order_release);

	const auto analog = [](unsigned index, unsigned id) {
		const int raw = input_state_cb(0, RETRO_DEVICE_ANALOG, index, id);
		return static_cast<uint32_t>(
		    std::clamp((raw + 0x8000) * 255 / 0xffff, 0, 255));
	};
	shared->axes[0][AXIS_LEFT_X] = analog(RETRO_DEVICE_INDEX_ANALOG_LEFT,
	                                      RETRO_DEVICE_ID_ANALOG_X);
	shared->axes[0][AXIS_LEFT_Y] = analog(RETRO_DEVICE_INDEX_ANALOG_LEFT,
	                                      RETRO_DEVICE_ID_ANALOG_Y);
	shared->axes[0][AXIS_RIGHT_X] = analog(RETRO_DEVICE_INDEX_ANALOG_RIGHT,
	                                       RETRO_DEVICE_ID_ANALOG_X);
	shared->axes[0][AXIS_RIGHT_Y] = analog(RETRO_DEVICE_INDEX_ANALOG_RIGHT,
	                                       RETRO_DEVICE_ID_ANALOG_Y);

	const auto trigger = [](unsigned id) {
		int raw = input_state_cb(0, RETRO_DEVICE_ANALOG, RETRO_DEVICE_INDEX_ANALOG_BUTTON, id);
		if (raw == 0 && input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, id) != 0) {
			raw = 0x7fff;
		}
		return static_cast<uint32_t>(std::clamp(raw * 255 / 0x7fff, 0, 255));
	};
	shared->axes[0][AXIS_TRIGGER_LEFT]  = trigger(RETRO_DEVICE_ID_JOYPAD_L2);
	shared->axes[0][AXIS_TRIGGER_RIGHT] = trigger(RETRO_DEVICE_ID_JOYPAD_R2);
}

void TakeFrame() {
	using namespace KytyLibretro;

	if (shared == nullptr) {
		return;
	}
	static std::atomic<uint32_t> diag_counter {0};
	for (int attempt = 0; attempt < 3; ++attempt) {
		const uint64_t latest = shared->frame_latest.load(std::memory_order_acquire);
		if (latest == 0 || (latest >> FRAME_SLOT_BITS) == shown_latest) {
			if ((diag_counter.fetch_add(1) % 1200) == 0) {
				DiagLog("TakeFrame: frame_latest=%llu shown_latest=%llu",
				        static_cast<unsigned long long>(latest),
				        static_cast<unsigned long long>(shown_latest));
			}
			return;
		}
		const uint32_t slot = static_cast<uint32_t>(latest & FRAME_SLOT_MASK);
		if (slot >= FRAME_SLOTS) {
			return;
		}
		shared->frame_held.store(slot, std::memory_order_release);
		if (shared->frame_latest.load(std::memory_order_acquire) != latest) {
			continue;
		}
		const uint32_t width  = shared->frame_size[slot].width;
		const uint32_t height = shared->frame_size[slot].height;
		if (width == 0 || height == 0 || width > MAX_WIDTH || height > MAX_HEIGHT) {
			shared->frame_held.store(FRAME_SLOT_NONE, std::memory_order_release);
			return;
		}
		frame_copy.resize(static_cast<size_t>(width) * height * 4);
		const auto* source = SharedFrame(shared, slot);
		for (uint32_t y = 0; y < height; ++y) {
			std::memcpy(frame_copy.data() + static_cast<size_t>(y) * width * 4,
			            source + static_cast<size_t>(y) * MAX_WIDTH * 4, static_cast<size_t>(width) * 4);
		}
		if (video_refresh_cb != nullptr) {
			if ((diag_counter.fetch_add(1) % 120) == 0) {
				DiagLog("TakeFrame: publishing %ux%u latest=%llu", width, height,
				        static_cast<unsigned long long>(latest));
			}
			video_refresh_cb(frame_copy.data(), width, height, width * 4);
		} else if ((diag_counter.fetch_add(1) % 120) == 0) {
			DiagLog("TakeFrame: no video callback for %ux%u latest=%llu", width, height,
			        static_cast<unsigned long long>(latest));
		}
		shown_latest = latest >> FRAME_SLOT_BITS;
		shared->frame_held.store(FRAME_SLOT_NONE, std::memory_order_release);
		return;
	}
	shared->frame_held.store(FRAME_SLOT_NONE, std::memory_order_release);
}

void TakeAudio() {
	using namespace KytyLibretro;

	if (shared == nullptr) {
		return;
	}
	static auto        last_take = std::chrono::steady_clock::now();
	static double      credit    = 0.0;
	const auto         now       = std::chrono::steady_clock::now();
	const double       elapsed   = std::chrono::duration<double>(now - last_take).count();
	last_take                    = now;
	credit                       = std::min(credit + elapsed * 48000.0, 2400.0);

	const uint32_t written = shared->audio_written.load(std::memory_order_acquire);
	const uint32_t read    = shared->audio_read.load(std::memory_order_relaxed);
	const uint32_t frames  = written - read;
	if (frames == 0) {
		return;
	}
	const uint32_t take  = std::min<uint32_t>({frames, static_cast<uint32_t>(credit), 4096u});
	const uint32_t first = std::min<uint32_t>(take, AUDIO_RING_FRAMES - (read & (AUDIO_RING_FRAMES - 1)));
	audio_copy.resize(static_cast<size_t>(take) * 2);
	std::memcpy(audio_copy.data(), shared->audio + (read & (AUDIO_RING_FRAMES - 1)) * 2,
	            static_cast<size_t>(first) * 2 * sizeof(int16_t));
	if (first < take) {
		std::memcpy(audio_copy.data() + static_cast<size_t>(first) * 2, shared->audio,
		            static_cast<size_t>(take - first) * 2 * sizeof(int16_t));
	}
	size_t done = take;
	if (audio_batch_cb != nullptr) {
		done = audio_batch_cb(audio_copy.data(), take);
	} else if (audio_sample_cb != nullptr) {
		for (size_t i = 0; i < take; ++i) {
			audio_sample_cb(audio_copy[i * 2], audio_copy[i * 2 + 1]);
		}
	}
	shared->audio_read.store(read + static_cast<uint32_t>(done), std::memory_order_release);
	credit = std::max(0.0, credit - static_cast<double>(done));
	static std::atomic<uint32_t> diag_counter {0};
	if ((diag_counter.fetch_add(1) % 240) == 0) {
		DiagLog("TakeAudio: written=%u read=%u frames=%u take=%u done=%zu credit=%.1f", written,
		        read, frames, take, done, credit);
	}
}

bool LaunchHost(const std::string& mapping_name) {
	const std::string directory = CoreDirectory();
	if (directory.empty()) {
		return false;
	}
	const std::wstring dll = Utf8ToWide(directory + "\\kytyps5_libretro.dll");
	const std::wstring name = Utf8ToWide(mapping_name);
	std::wstring command = L"rundll32.exe \"" + dll + L"\",retro_host_main \"" + name + L"\"";

	STARTUPINFOW startup {};
	startup.cb         = sizeof(startup);
	startup.dwFlags    = STARTF_USESHOWWINDOW;
	startup.wShowWindow = SW_HIDE;
	PROCESS_INFORMATION process {};
	DiagLog("LaunchHost: %ls", command.c_str());
	const BOOL created = CreateProcessW(nullptr, command.data(), nullptr, nullptr, FALSE,
	                                    CREATE_NO_WINDOW, nullptr, nullptr, &startup, &process);
	if (!created) {
		DiagLog("LaunchHost: CreateProcessW failed error=%lu", GetLastError());
		return false;
	}
	DiagLog("LaunchHost: started pid=%lu", process.dwProcessId);
	CloseHandle(process.hThread);
	host_process = process.hProcess;
	monitor_thread = CreateThread(nullptr, 0, HostMonitorThread, nullptr, 0, nullptr);
	if (monitor_thread == nullptr) {
		DiagLog("LaunchHost: HostMonitorThread failed error=%lu", GetLastError());
	}
	return true;
}

DWORD WINAPI EmulatorThread(LPVOID) {
	using namespace KytyLibretro;

	emulator_thread_id = GetCurrentThreadId();
	if (shared == nullptr) {
		DiagLog("EmulatorThread: shared is null");
		return 2;
	}
	DiagLog("EmulatorThread: start game=%s user=%s", shared->game_path, shared->user_dir);
	const std::filesystem::path game_path =
	    Common::PathFromUtf8(Common::FixFilenameSlash(shared->game_path));
	Emulator::RunOptions options;
	options.config.screen_width  = shared->screen_width.load() != 0
	                                   ? shared->screen_width.load()
	                                   : 1280;
	options.config.screen_height = shared->screen_height.load() != 0
	                                   ? shared->screen_height.load()
	                                   : 720;
	options.config.libretro_bridge  = true;
	options.config.gpu_index             = 0;
	options.config.printf_direction       = Config::LogDirection::File;
	options.config.printf_output_file     = "kytyps5_libretro.log";
	options.config.splash_enabled   = false;
	options.config.skip_notice_screen = true;
	options.config.hdr_enabled      = false;
	options.config.fullscreen_enabled = false;
	options.config.vblank_frequency = 60;

	if (Common::File::IsDirectoryExisting(game_path)) {
		options.app0_dir = game_path;
		options.elf      = "/app0/eboot.bin";
	} else if (Common::IsSupportedArchive(game_path) && Common::File::IsFileExisting(game_path)) {
		const auto root = Common::MakeArchivePath(game_path);
		if (!Common::File::IsFileExisting(root / "eboot.bin")) {
			return 3;
		}
		options.app0_dir = root;
		options.elf      = "/app0/eboot.bin";
	} else if (Common::File::IsFileExisting(game_path)) {
		options.app0_dir = game_path.parent_path();
		if (options.app0_dir.empty()) {
			options.app0_dir = ".";
		}
		options.elf = std::filesystem::path("/app0") / game_path.filename();
	} else {
		return 4;
	}

	DiagLog("EmulatorThread: app0=%s elf=%s", options.app0_dir.string().c_str(),
	        options.elf.string().c_str());
	Common::InitializeThreads();
	try {
		DiagLog("EmulatorThread: calling Emulator::Run");
		Emulator::Run(options);
		DiagLog("EmulatorThread: Emulator::Run returned");
	} catch (const std::exception& e) {
		DiagLog("EmulatorThread: std::exception: %s", e.what());
		return 5;
	} catch (...) {
		DiagLog("EmulatorThread: unknown exception");
		return 6;
	}
	return 0;
}

DWORD WINAPI AudioThread(LPVOID) {
	audio_thread_id = GetCurrentThreadId();
	Kyty::LibretroBridge::AudioPumpLoop();
	return 0;
}

} // namespace

extern "C" RETRO_API void retro_init(void) {}

extern "C" RETRO_API void retro_deinit(void) {}

extern "C" RETRO_API unsigned retro_api_version(void) {
	return RETRO_API_VERSION;
}

extern "C" RETRO_API void retro_get_system_info(struct retro_system_info* info) {
	if (info == nullptr) {
		return;
	}
	info->library_name     = "KytyPS5";
	info->library_version  = "libretro";
	info->valid_extensions = "bin|elf|zar";
	info->need_fullpath    = true;
	info->block_extract    = true;
}

extern "C" RETRO_API void retro_get_system_av_info(struct retro_system_av_info* info) {
	if (info == nullptr) {
		return;
	}
	info->geometry.base_width   = 1280;
	info->geometry.base_height  = 720;
	info->geometry.max_width    = KytyLibretro::MAX_WIDTH;
	info->geometry.max_height   = KytyLibretro::MAX_HEIGHT;
	info->geometry.aspect_ratio = 16.0f / 9.0f;
	info->timing.fps            = 60.0;
	info->timing.sample_rate    = 48000.0;
}

extern "C" RETRO_API void retro_set_environment(retro_environment_t cb) {
	environ_cb = cb;
}

extern "C" RETRO_API void retro_set_video_refresh(retro_video_refresh_t cb) {
	video_refresh_cb = cb;
}

extern "C" RETRO_API void retro_set_audio_sample(retro_audio_sample_t cb) {
	audio_sample_cb = cb;
}

extern "C" RETRO_API void retro_set_audio_sample_batch(retro_audio_sample_batch_t cb) {
	audio_batch_cb = cb;
}

extern "C" RETRO_API void retro_set_input_poll(retro_input_poll_t cb) {
	input_poll_cb = cb;
}

extern "C" RETRO_API void retro_set_input_state(retro_input_state_t cb) {
	input_state_cb = cb;
}

extern "C" RETRO_API void retro_set_controller_port_device(unsigned, unsigned) {}

extern "C" RETRO_API void retro_reset(void) {}

extern "C" RETRO_API void retro_run(void) {
	if (shared == nullptr) {
		return;
	}
	if (input_poll_cb != nullptr) {
		input_poll_cb();
	}
	SendInput();
	TakeAudio();
	TakeFrame();
	std::this_thread::sleep_for(std::chrono::milliseconds(1));
}

extern "C" RETRO_API bool retro_load_game(const struct retro_game_info* info) {
	if (shared != nullptr || info == nullptr || info->path == nullptr) {
		return false;
	}
	const retro_pixel_format format = RETRO_PIXEL_FORMAT_XRGB8888;
	if (environ_cb == nullptr || !environ_cb(RETRO_ENVIRONMENT_SET_PIXEL_FORMAT,
	                                        const_cast<retro_pixel_format*>(&format))) {
		return false;
	}
	const char* save_directory = nullptr;
	if (environ_cb != nullptr &&
	    !environ_cb(RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY, &save_directory)) {
		save_directory = nullptr;
	}
	const std::string mapping_name = "Local\\kytyps5_libretro_" +
	                                 std::to_string(GetCurrentProcessId()) + "_" +
	                                 std::to_string(mapping_counter.fetch_add(1));
	shared_mapping = CreateFileMappingA(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0,
	                                     static_cast<DWORD>(sizeof(KytyLibretro::SharedState)),
	                                     mapping_name.c_str());
	if (shared_mapping == nullptr) {
		return false;
	}
	shared = static_cast<KytyLibretro::SharedState*>(
	    MapViewOfFile(shared_mapping, FILE_MAP_ALL_ACCESS, 0, 0,
	                  sizeof(KytyLibretro::SharedState)));
	if (shared == nullptr) {
		CloseHandle(shared_mapping);
		shared_mapping = nullptr;
		return false;
	}
	std::memset(shared, 0, sizeof(*shared));
	shared->magic.store(KytyLibretro::SHARED_MAGIC);
	shared->version.store(KytyLibretro::SHARED_VERSION);
	shared->pads.store(1);
	shared->screen_width.store(1280);
	shared->screen_height.store(720);
	CopyText(shared->game_path, sizeof(shared->game_path), info->path);
	CopyText(shared->user_dir, sizeof(shared->user_dir),
	         save_directory != nullptr ? save_directory : CoreDirectory().c_str());
	shared->frame_held.store(KytyLibretro::FRAME_SLOT_NONE);
	shared->ready.store(1);
	shown_latest = 0;
	DiagLog("retro_load_game: path=%s mapping=%s save=%s", info->path, mapping_name.c_str(),
	        shared->user_dir);
	if (!LaunchHost(mapping_name)) {
		DiagLog("retro_load_game: LaunchHost failed");
		UnmapViewOfFile(shared);
		shared = nullptr;
		CloseHandle(shared_mapping);
		shared_mapping = nullptr;
		return false;
	}
	return true;
}

extern "C" RETRO_API bool retro_load_game_special(unsigned, const struct retro_game_info*, size_t) {
	return false;
}

extern "C" RETRO_API void retro_unload_game(void) {
	if (shared != nullptr) {
		shared->quit.store(1);
	}
	if (host_process != nullptr) {
		const DWORD result = WaitForSingleObject(host_process, 5000);
		DiagLog("retro_unload_game: host wait=%lu", result);
		if (result == WAIT_TIMEOUT) {
			TerminateProcess(host_process, 0);
		}
		CloseHandle(host_process);
		host_process = nullptr;
	}
	if (monitor_thread != nullptr) {
		WaitForSingleObject(monitor_thread, 1000);
		CloseHandle(monitor_thread);
		monitor_thread = nullptr;
	}
	if (shared != nullptr) {
		UnmapViewOfFile(shared);
		shared = nullptr;
	}
	if (shared_mapping != nullptr) {
		CloseHandle(shared_mapping);
		shared_mapping = nullptr;
	}
	shown_latest = 0;
}

extern "C" RETRO_API unsigned retro_get_region(void) {
	return 1;
}

extern "C" RETRO_API size_t retro_serialize_size(void) {
	return 0;
}

extern "C" RETRO_API bool retro_serialize(void*, size_t) {
	return false;
}

extern "C" RETRO_API bool retro_unserialize(const void*, size_t) {
	return false;
}

extern "C" RETRO_API void retro_cheat_reset(void) {}

extern "C" RETRO_API void retro_cheat_set(unsigned, bool, const char*) {}

extern "C" RETRO_API void* retro_get_memory_data(unsigned) {
	return nullptr;
}

extern "C" RETRO_API size_t retro_get_memory_size(unsigned) {
	return 0;
}

extern "C" __declspec(dllexport) void CALLBACK retro_host_main(HWND, HINSTANCE, LPSTR command_line,
                                                               int) {
	std::string argument = command_line != nullptr ? command_line : "";
	const auto  first    = argument.find_first_not_of(" \t\"");
	const auto  last     = argument.find_last_not_of(" \t\"\r\n");
	argument = first == std::string::npos ? "" : argument.substr(first, last - first + 1);

	DiagLog("retro_host_main: arg=%s", argument.c_str());
	AddVectoredExceptionHandler(1, DiagExceptionFilter);
	KytyLibretro::SharedState* host_shared = OpenShared(argument.c_str());
	if (host_shared == nullptr) {
		DiagLog("retro_host_main: OpenShared failed");
		ExitProcess(2);
	}
	DiagLog("retro_host_main: shared ready=%u game=%s user=%s", host_shared->ready.load(),
	        host_shared->game_path, host_shared->user_dir);
	shared = host_shared;
	Kyty::LibretroBridge::SetSharedState(host_shared);
	Kyty::LibretroBridge::SetBaseDir(CoreDirectory().c_str());
	const HANDLE log_flush_thread =
	    CreateThread(nullptr, 0, LogFlushThread, nullptr, 0, nullptr);
	if (log_flush_thread == nullptr) {
		DiagLog("retro_host_main: LogFlushThread failed error=%lu", GetLastError());
	} else {
		CloseHandle(log_flush_thread);
	}

	const std::wstring user_directory = Utf8ToWide(host_shared->user_dir);
	if (!user_directory.empty()) {
		CreateDirectoryW(user_directory.c_str(), nullptr);
		SetCurrentDirectoryW(user_directory.c_str());
	}
	SDL_InitSubSystem(SDL_INIT_AUDIO);

	const HANDLE audio_thread = CreateThread(nullptr, 0, AudioThread, nullptr, 0, nullptr);
	(void)audio_thread;
	const HANDLE emulator_thread =
	    CreateThread(nullptr, 0x200000, EmulatorThread, nullptr, 0, nullptr);
	if (emulator_thread == nullptr) {
		DiagLog("retro_host_main: CreateThread failed error=%lu", GetLastError());
		ExitProcess(3);
	}
	DiagLog("retro_host_main: threads started");
	WaitForSingleObject(emulator_thread, INFINITE);
	DWORD code = 0;
	GetExitCodeThread(emulator_thread, &code);
	DiagLog("retro_host_main: emulator exited code=%lu", code);
	ExitProcess(code);
}
